<?php
// Database connection
$host = 'localhost';
$db_name = 'hresort'; // Replace with your database name
$username = 'jake'; // Default XAMPP username
$password = 'jake'; // Default XAMPP password

$conn = new mysqli($host, $username, $password, $db_name);

// Check connection
if ($conn->connect_error) {
    die(json_encode(['error' => 'Database connection failed']));
}
?>