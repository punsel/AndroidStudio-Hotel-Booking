<?php
header('Content-Type: application/json');

include('database.php');

$bookingid = $_POST['bookingid'];
$roomtype = $_POST['roomtype'];
$nights = $_POST['nights']; 
$total = $_POST['total'];
$paid = $_POST['paid']; 
$changee = $_POST['change'];






// Validate the input
if (empty($bookingid) || empty($roomtype) || empty($nights)) {
    echo json_encode(["message" => "Empty fields."]);
    exit();
}

// Update query
$query = "UPDATE bookings SET roomtype = ?, nights = ?, total = ?, paid = ?, changee = ? WHERE bookingid = ?";

$stmt = $conn->prepare($query);
$stmt->bind_param("sssssi", $roomtype,$nights,$total,$paid,$changee,$bookingid);

if ($stmt->execute()) {
    echo json_encode(["message" => "Data updated successfully"]);
} else {
    echo json_encode(["message" => "Failed to update data"]);
}

$stmt->close();
$conn->close();


?>


