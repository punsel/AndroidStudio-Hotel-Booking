<?php 


include('database.php');

$roomtype = $_POST['roomtype'];
$nights = $_POST['nights']; 
$total = $_POST['total'];
$paid = $_POST['paid']; 
$changee = $_POST['change']; 


// Corrected SQL query string
$sql = "INSERT INTO bookings (roomtype, nights, total, paid, changee) 
        VALUES ('$roomtype', '$nights', '$total', '$paid', '$changee')";

// Execute query
if ($conn->query($sql) === TRUE) {
    echo json_encode(array('message' => 'RECORD SUCCESSFULLY'));
} else {
    echo json_encode(array('message' => 'ERROR: ' . $conn->error));
}

// Close the database connection
$conn->close();




?>