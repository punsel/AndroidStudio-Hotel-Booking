<?php
include('database.php');

$id = $_POST['id'];

if(isset($id)){
	$sql = "DELETE FROM bookings WHERE bookingid =?";
	if($stmt = $conn->prepare($sql)){
		$stmt->bind_param("s",$id);
		if($stmt->execute()){
			if($stmt->affected_rows >0){
				echo json_encode( array('message' => 'Delete successfully'));
			}else{
				echo json_encode( array('message' => 'No changes on data'));
			}
		}else{
			echo json_encode( array('message' => 'Error updating query'));
		}
		$stmt->close();
	}else{
		echo json_encode( array('message' => 'Error preparing query'));
	}
}else{
	echo json_encode( array('message' => 'Invalid input arguments'));
}
?>