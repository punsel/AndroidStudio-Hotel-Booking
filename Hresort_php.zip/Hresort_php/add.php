<?php 
include('database.php');

$name = $_POST['name'];
$email = $_POST['email'];
$password = $_POST['password'];




// SQL statement with correct syntax and table name
$sql = "INSERT INTO user (name, email, password) 
        VALUES ('$name', '$email', '$password')";



// Execute query
if ($conn->query($sql) === TRUE) {
    echo json_encode(array('message' => 'RECORD SUCCESSFULLY'));
} else {
    echo json_encode(array('message' => 'ERROR: ' .$conn->error));
}

$conn->close();
?>