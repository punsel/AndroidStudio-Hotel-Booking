<?php


// Include the database connection
include('database.php');

header('Content-Type: application/json');


// Check if the 'selectedID' parameter is set
if (isset($_GET['selectedID'])) {
    $selectedID = $_GET['selectedID'];

    // Use a prepared statement to prevent SQL Injection
    $stmt = $conn->prepare("SELECT bookingid, roomtype, nights, total, paid, changee FROM bookings WHERE bookingid = ?");
    $stmt->bind_param("s", $selectedID); // Change "s" to "i" if bookingid is an integer

    $stmt->execute();
    $result = $stmt->get_result();

    // Check if a record is found
    if ($result->num_rows > 0) {
        $data = $result->fetch_assoc();
        echo json_encode($data); // Send the result as a JSON object
    } else {
        echo json_encode(["error" => "No record found"]);
    }

    $stmt->close();
} else {
    echo json_encode(["error" => "No selectedID provided"]);
}

$conn->close();
// include('database.php');


// if(isset($_GET['selectedID'])){
//  $sql = "SELECT * FROM bookings WHERE bookingid = '".$_GET['selectedID']."'";
//  $result = $conn->query($sql);
//  if($result-> num_rows>0){
//   $data = $result->fetch_assoc();
//      echo json_encode($result);
// }
// }

// $conn->close();
?>
